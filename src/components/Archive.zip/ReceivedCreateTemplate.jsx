import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { TransitionGroup, CSSTransition } from 'react-transition-group';
import './dashboard.css';
import './ReceivedCreateTemplate.css';
import Sidebar from './Sidebar';

const ReceivedCreateTemplate = ({ userEmail }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('Current');
  const [showSettings, setShowSettings] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  // Initialize templateData with location.state.template if available
  const initialTemplateData = location.state?.template || {
    name: '',
    model: 'gpt-4.1-mini',
    maxTokens: '',
    temperature: '',
    topP: '',
    systemPrompt: '',
    emailExamples: [''],
    type: 'received',
  };

  const [templateData, setTemplateData] = useState(initialTemplateData);
  const [systemPromptWordCount, setSystemPromptWordCount] = useState(0);
  const [emailExampleWordCounts, setEmailExampleWordCounts] = useState(
    initialTemplateData.emailExamples.map((example) =>
      example.trim().split(/\s+/).filter((word) => word.length > 0).length
    )
  );
  const settingsRef = useRef(null);
  const maxTokensRef = useRef(null);
  const temperatureRef = useRef(null);
  const topPRef = useRef(null);

  // Update word counts when templateData changes
  useEffect(() => {
    const systemPromptWords = templateData.systemPrompt
      .trim()
      .split(/\s+/)
      .filter((word) => word.length > 0);
    setSystemPromptWordCount(systemPromptWords.length);

    const newEmailWordCounts = templateData.emailExamples.map((example) =>
      example.trim().split(/\s+/).filter((word) => word.length > 0).length
    );
    setEmailExampleWordCounts(newEmailWordCounts);
  }, [templateData.systemPrompt, templateData.emailExamples]);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setTemplateData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (name === 'systemPrompt') {
      const words = value.trim().split(/\s+/).filter((word) => word.length > 0);
      setSystemPromptWordCount(words.length);
    }
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleSliderChange = (name, value, e) => {
    setTemplateData((prev) => ({
      ...prev,
      [name]: value,
    }));
    const input = e.target;
    const min = parseFloat(input.min) || 0;
    const max = parseFloat(input.max) || 100;
    const val = parseFloat(value) || 0;
    const percentage = ((val - min) / (max - min)) * 100;
    input.style.setProperty('--value', `${percentage}%`);
    setFormErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleEmailExampleChange = (index, value) => {
    const updatedExamples = [...templateData.emailExamples];
    updatedExamples[index] = value;
    setTemplateData((prev) => ({
      ...prev,
      emailExamples: updatedExamples,
    }));
    const words = value.trim().split(/\s+/).filter((word) => word.length > 0);
    setEmailExampleWordCounts((prev) => {
      const newCounts = [...prev];
      newCounts[index] = words.length;
      return newCounts;
    });
    setFormErrors((prev) => ({ ...prev, emailExamples: '' }));
  };

  const handleAddEmailExample = () => {
    setTemplateData((prev) => ({
      ...prev,
      emailExamples: [...prev.emailExamples, ''],
    }));
    setEmailExampleWordCounts((prev) => [...prev, 0]);
  };

  const handleDeleteEmailExample = (index) => {
    setTemplateData((prev) => ({
      ...prev,
      emailExamples: prev.emailExamples.filter((_, i) => i !== index),
    }));
    setEmailExampleWordCounts((prev) => prev.filter((_, i) => i !== index));
  };

  const handleBack = () => {
    navigate('/dashboard');
  };

  const validateForm = () => {
    const errors = {};
    if (!userEmail) errors.userEmail = 'User email is required';
    if (!templateData.name.trim()) errors.name = 'Template name is required';
    if (!templateData.systemPrompt.trim()) errors.systemPrompt = 'System prompt is required';
    if (!templateData.emailExamples || templateData.emailExamples.length === 0 || templateData.emailExamples.every((ex) => !ex.trim())) {
      errors.emailExamples = 'At least one non-empty email example is required';
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePublish = async () => {
    if (!validateForm()) {
      alert('Please fill in all required fields');
      return;
    }

    const confirmed = window.confirm('Are you sure you want to publish this template?');
    if (!confirmed) {
      console.log('Publish cancelled by user');
      return;
    }

    setIsPublishing(true);
    try {
      const payload = {
        ...templateData,
        userEmail,
        id: templateData.id || Date.now().toString(),
        type: 'received',
        maxTokens: templateData.maxTokens && !isNaN(parseFloat(templateData.maxTokens)) ? parseFloat(templateData.maxTokens) : undefined,
        temperature: templateData.temperature && !isNaN(parseFloat(templateData.temperature)) ? parseFloat(templateData.temperature) : undefined,
        topP: templateData.topP && !isNaN(parseFloat(templateData.topP)) ? parseFloat(templateData.topP) : undefined,
      };

      const response = await fetch('https://2ofjdl14kg.execute-api.us-east-1.amazonaws.com/prod/publish-received', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to publish template');
      }

      const result = await response.json();
      console.log('Template published:', result);

      navigate('/dashboard', {
        state: {
          newTemplate: {
            ...templateData,
            id: result.templateId,
            category: result.category,
            type: 'received',
          },
        },
      });
    } catch (error) {
      console.error('Error publishing template:', error.message);
      alert(`Failed to publish template: ${error.message}`);
    } finally {
      setIsPublishing(false);
    }
  };

  const handleUpgradeToPro = () => {
    console.log('Upgrade to Pro button clicked in CreateTemplate');
  };

  useEffect(() => {
    if (showSettings) {
      const sliders = [
        { ref: maxTokensRef, value: templateData.maxTokens, min: 0, max: 4096 },
        { ref: temperatureRef, value: templateData.temperature, min: 0, max: 2 },
        { ref: topPRef, value: templateData.topP, min: 0, max: 1 },
      ];

      sliders.forEach(({ ref, value, min, max }) => {
        if (ref.current) {
          const val = parseFloat(value) || 0;
          const percentage = ((val - min) / (max - min)) * 100;
          ref.current.style.setProperty('--value', `${percentage}%`);
        }
      });
    }
  }, [showSettings, templateData.maxTokens, templateData.temperature, templateData.topP]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (settingsRef.current && !settingsRef.current.contains(event.target)) {
        setShowSettings(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="taq-container">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} navigate={navigate} />
      <div className="tab-bar received-create-goal-active">
        <div className="tab-bar-content">
          <div className="tab-bar-left">
            <button className="received-create-goal-back-button" onClick={handleBack}>
              <img
                src="/assets/back_button_left_arrow.png"
                alt="Back"
                className="back-button-icon"
              />
              <span className="back-button-text">Back</span>
            </button>
            <textarea
              name="name"
              value={templateData.name}
              onChange={handleInputChange}
              placeholder="Untitled template"
              className="received-create-template-name-input"
              rows="1"
              style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}
            />
            {formErrors.name && <span className="error">{formErrors.name}</span>}
          </div>
          <div className="received-create-template-controls">
            <button className="upgrade-to-pro-button" onClick={handleUpgradeToPro}>
              Upgrade to Pro
            </button>
            <button
              className="publish-button"
              onClick={handlePublish}
              disabled={isPublishing}
            >
              {isPublishing ? 'Publishing...' : 'Publish'}
            </button>
          </div>
        </div>
      </div>
      <main className="dashboard-content">
        <div className="received-create-template-grid">
          <div className="received-create-template-column">
            <div className="received-create-template-block received-ai-parameters-block">
              <div className="received-create-template-block-header">
                <h3>AI Parameters</h3>
                <div
                  className="received-settings-icon-container"
                  ref={settingsRef}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  {(isHovered || showSettings) && (
                    <div
                      className={`received-settings-icon-background ${isHovered && !showSettings ? 'hovered' : ''}`}
                    />
                  )}
                  <img
                    src={
                      showSettings
                        ? '/assets/ai_parameter_icon_set_up_selected.png'
                        : '/assets/ai_parameter_icon_set_up_non-selected.png'
                    }
                    alt="Settings"
                    className={`received-settings-icon ${showSettings ? 'received-settings-icon-active' : ''}`}
                    onClick={() => setShowSettings(!showSettings)}
                  />
                  {showSettings && (
                    <div className="received-settings-menu">
                      <div className="received-slider-container">
                        <div className="received-slider-label-value">
                          <span className="received-slider-label">Max Tokens</span>
                          <span className="received-slider-value">{templateData.maxTokens || 0}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="4096"
                          value={templateData.maxTokens || 0}
                          onChange={(e) => handleSliderChange('maxTokens', e.target.value, e)}
                          className="received-slider-max-tokens"
                          ref={maxTokensRef}
                        />
                      </div>
                      <div className="received-slider-container">
                        <div className="received-slider-label-value">
                          <span className="received-slider-label">Temperature</span>
                          <span className="received-slider-value">{templateData.temperature || 0}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="2"
                          step="0.1"
                          value={templateData.temperature || 0}
                          onChange={(e) => handleSliderChange('temperature', e.target.value, e)}
                          className="received-slider-temperature"
                          ref={temperatureRef}
                        />
                      </div>
                      <div className="received-slider-container">
                        <div className="received-slider-label-value">
                          <span className="received-slider-label">Top P</span>
                          <span className="received-slider-value">{templateData.topP || 0}</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.1"
                          value={templateData.topP || 0}
                          onChange={(e) => handleSliderChange('topP', e.target.value, e)}
                          className="received-slider-top-p"
                          ref={topPRef}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="received-create-template-row">
                <div className="received-create-template-field">
                  <label>Model</label>
                  <div className="received-select-container">
                    <select
                      name="model"
                      value={templateData.model}
                      onChange={handleInputChange}
                      className="received-create-template-select"
                    >
                      <option value="gpt-4.1-mini">gpt-4.1-mini</option>
                      <option value="gpt-o3">gpt-o3</option>
                    </select>
                  </div>
                </div>
              </div>
              <div className="received-create-template-row received-create-template-row-multi">
                <div className="received-create-template-field">
                  <label>Max Tokens</label>
                  <input
                    type="number"
                    name="maxTokens"
                    value={templateData.maxTokens}
                    onChange={handleInputChange}
                    placeholder="100"
                  />
                </div>
                <div className="received-create-template-field">
                  <label>Temperature</label>
                  <input
                    type="number"
                    name="temperature"
                    value={templateData.temperature}
                    onChange={handleInputChange}
                    placeholder="0.7"
                    step="0.1"
                  />
                </div>
                <div className="received-create-template-field">
                  <label>Top P</label>
                  <input
                    type="number"
                    name="topP"
                    value={templateData.topP}
                    onChange={handleInputChange}
                    placeholder="0.9"
                    step="0.1"
                  />
                </div>
              </div>
            </div>
            <div className="received-create-template-block received-create-template-system-prompt-block">
              <div className="received-create-template-block-header">
                <h3>System Prompt</h3>
              </div>
              <div className="received-system-prompt-textarea-container">
                <textarea
                  name="systemPrompt"
                  value={templateData.systemPrompt}
                  onChange={handleInputChange}
                  placeholder="Write a response to this email like a professional customer support agent"
                  rows="10"
                />
                <span className="received-word-count">
                  {systemPromptWordCount} {systemPromptWordCount === 1 ? 'word' : 'words'}
                </span>
                {formErrors.systemPrompt && <span className="error">{formErrors.systemPrompt}</span>}
              </div>
            </div>
          </div>
          <div className="received-create-template-column">
            <div className="received-create-template-block received-create-template-email-examples-block">
              <div className="received-create-template-block-header">
                <h3>Email Examples</h3>
              </div>
              <div className="received-email-examples-content">
                <TransitionGroup component="div" className="received-email-examples-container">
                  {templateData.emailExamples.map((example, index) => (
                    <CSSTransition key={index} timeout={500} classNames="received-email-example">
                      <div className="received-email-example-container">
                        <div className="received-email-example-textarea-container">
                          <textarea
                            value={example}
                            onChange={(e) => handleEmailExampleChange(index, e.target.value)}
                            placeholder={`Subject: Customer Inquiry\nDear Support,\nI have an issue with my order #12345...\n\nSincerely,\nCustomer`}
                            rows="8"
                            className="received-create-template-email-example"
                          />
                          <span className="received-word-count">
                            {emailExampleWordCounts[index] || 0}{' '}
                            {emailExampleWordCounts[index] === 1 ? 'word' : 'words'}
                          </span>
                        </div>
                        {index > 0 && (
                          <div className="received-delete-button-wrapper">
                            <button
                              className="received-delete-example-button"
                              onClick={() => handleDeleteEmailExample(index)}
                              title="Delete this example"
                            >
                              ×
                            </button>
                          </div>
                        )}
                      </div>
                    </CSSTransition>
                  ))}
                </TransitionGroup>
                {formErrors.emailExamples && <span className="error">{formErrors.emailExamples}</span>}
                <button className="received-add-example-button" onClick={handleAddEmailExample}>
                  <span className="received-plus-symbol">+</span> Add Additional Example
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ReceivedCreateTemplate;